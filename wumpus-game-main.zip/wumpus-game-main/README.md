# wumpus-world-java-2
The Wumpus World was introduced by Genesereth, and is discussed in Russell-Norvig. The Wumpus World is a simple world (as is the Block World) for which to represent knowledge and to reason.  It is a cave with a number of rooms, represented as a 4x4 square.  I have implemeted this game using if-and-else,A* algorithm,probability.

Project in Artificial Intelligence to implement navies bayes  and A* algorithms to train the AI agent.
